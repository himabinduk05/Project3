package com.da.service;

import com.da.beans.LoginBean;

public interface LoginService {
	String validateCustomer(LoginBean login);
}
