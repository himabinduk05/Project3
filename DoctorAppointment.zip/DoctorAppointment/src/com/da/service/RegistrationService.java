package com.da.service;

import com.da.beans.PatientBean;


public interface RegistrationService {
	public void insertPatient(PatientBean pat);
}
