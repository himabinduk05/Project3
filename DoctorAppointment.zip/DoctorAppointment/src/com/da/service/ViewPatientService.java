package com.da.service;

import java.util.List;

import com.da.beans.AppointmentBean;

public interface ViewPatientService {
	public List viewPatientDetails(AppointmentBean appointment);
}
