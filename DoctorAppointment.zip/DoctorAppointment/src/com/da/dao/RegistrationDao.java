package com.da.dao;

import com.da.beans.PatientBean;
import com.da.beans.RegistrationBean;

public interface RegistrationDao {
		void insertPatient(PatientBean pat);
}

