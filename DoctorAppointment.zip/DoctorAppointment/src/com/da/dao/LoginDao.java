package com.da.dao;

import com.da.beans.LoginBean;

public interface LoginDao {
	String validateCustomer(LoginBean login);
}
